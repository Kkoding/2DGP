import game_framework

import start_state
import title_state
import ready_state

game_framework.run(start_state)